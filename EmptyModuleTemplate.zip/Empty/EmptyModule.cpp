#include "Runtime/Empty/UtilsModule.h"

DEFINE_LOG_CATEGORY(EmptyModuleLog);
 
#define LOCTEXT_NAMESPACE "FEmpty"
 
void FEmptyModule::StartupModule()
{
	UE_LOG(EmptyModuleLog, Log, TEXT("EmptyModule module has started!"));
}
 
void FEmptyModule::ShutdownModule()
{
	UE_LOG(EmptyModuleLog, Log, TEXT("EmptyModule module has shut down"));
}
 
#undef LOCTEXT_NAMESPACE
 
IMPLEMENT_MODULE(FEmptyModule, Utils)