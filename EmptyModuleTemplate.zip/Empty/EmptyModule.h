#pragma once
 
#include <Runtime/Core/Public/Modules/ModuleManager.h>
 
DECLARE_LOG_CATEGORY_EXTERN(EmptyModuleLog, All, All);
 
class FEmptyModule : public IModuleInterface
{
	public:
 
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
